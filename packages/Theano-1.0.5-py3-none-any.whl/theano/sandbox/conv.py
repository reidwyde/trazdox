from __future__ import absolute_import, print_function, division
import sys
print("DEPRECATION: theano.sandbox.conv no longer provides conv. "
      "They have been moved to theano.tensor.nnet.conv", file=sys.stderr)
