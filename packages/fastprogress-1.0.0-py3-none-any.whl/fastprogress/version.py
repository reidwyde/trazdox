from nbdev import imports
__all__ = ['__version__']
__version__ = imports.Config().version